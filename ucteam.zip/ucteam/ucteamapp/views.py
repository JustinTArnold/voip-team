from django.shortcuts import render
from django.template import loader   
from django.http import HttpResponse 
  
def hello(request):  
    return HttpResponse("<h2>Hello, Welcome to Django!</h2>")
def login(request):
    if request.method == 'POST':
        info=request.POST['info']
        print (info)
    else:
        template = loader.get_template('login.html')
        return HttpResponse(template.render())
def home(request):
    template = loader.get_template('home.html')
    return HttpResponse(template.render())
