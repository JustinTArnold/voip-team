from django.contrib import admin  
from django.urls import path
from django.conf.urls import url
from ucteamapp import views  
from django_csrf_protect_form import csrf_protect_form

urlpatterns = [  
    path('admin/', admin.site.urls),  
    path('hello/', views.hello),  
    url('login/', views.login, name='login'),
    path('home/', views.home),
    #path('login/submit', views.login)
]  